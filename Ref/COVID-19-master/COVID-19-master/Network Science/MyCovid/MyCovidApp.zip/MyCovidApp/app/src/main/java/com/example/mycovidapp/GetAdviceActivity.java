package com.example.mycovidapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class GetAdviceActivity extends AppCompatActivity {

    private TextView adviceField;
    private Button backBtn;

    private FirebaseAuth mAuth;
    private ProgressDialog mProgress;
    private DatabaseReference mDatabase;
    private String user_id;
    private URL url;
    private String jsonInputString ;//= "{\"feed_script\": \"u1, 41.2069510, 72.1249581, R\nu2, 41.2069521, 72.1249584, I\nu3, 41.2069513, 72.1249579, S\nu4, 41.2069505, 72.1249590, S\nu5, 41.2069504, 72.1249582, S\"}";
    private String data = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_advice);

        mAuth = FirebaseAuth.getInstance();
        user_id = mAuth.getCurrentUser().getUid();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(user_id);

        mProgress = new ProgressDialog(this);

        adviceField = findViewById(R.id.advice);
        backBtn = findViewById(R.id.Back);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(GetAdviceActivity.this,MapsActivity.class);
                mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
            }
        });




        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String latitude = dataSnapshot.child("output_Latitude").getValue().toString();//.substring(1, dataSnapshot.child("Latitude").getValue().toString().length()-1);
                String longitude = dataSnapshot.child("output_Longitude").getValue().toString();
                String name = dataSnapshot.child("Name").getValue().toString();//.substring(1, dataSnapshot.child("Latitude").getValue().toString().length()-1);
                String status = dataSnapshot.child("Status").getValue().toString();
                adviceField.setText("User:\n" + name + "\n\nLatitude : \n" + latitude + "\n\nLongitude : \n" + longitude + "\n\nCurrent Status:\n");
                if(status == "R")
                {
                    adviceField.append("Recovered");
                }
                else if(status == "I")
                {
                    adviceField.append("Infected");
                }
                else
                {
                    adviceField.append("Susceptible");
                }
//                data = "";
//                for(DataSnapshot snapshot : dataSnapshot.getChildren())
//                {
//
//                    data = data + snapshot.getKey() + ", "+ snapshot.child("Latitude").getValue().toString()
//                          +", "  + snapshot.child("Longitude").getValue().toString() + ", "+ snapshot.child("Status").getValue().toString()
//                            + "\n";
//                }

                //jsonInputString = "{\"feed_script\" : " + "\""+ data  + "\""+ "}";
                //adviceField.setText(jsonInputString);

//                {
//                    try {
//                        url = new URL ("https://simplenodebackend.herokuapp.com/process_update");
//                    } catch (MalformedURLException e) {
//                        e.printStackTrace();
//                    }
//                }
//                HttpURLConnection con = null;
//                try {
//                    con = (HttpURLConnection)url.openConnection();
//                    adviceField.append("\nconnection opened\n");
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    adviceField.append("Sorry, couldn't connect to server!!!");
//                }
//                try {
//                    con.setRequestMethod("POST");
//                    adviceField.append("\nrequest set to post\n");
//                } catch (ProtocolException e) {
//                    e.printStackTrace();
//                    adviceField.setText("Sorry, couldn't send request to server!!!");
//                }
//
////        con.setRequestProperty("Content-Type", "application/json; utf-8");
////        con.setRequestProperty("Accept", "application/string");
//                con.setDoOutput(true);
//                con.setDoInput(true);
//                con.setAllowUserInteraction(true);
////                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
////                con.setRequestProperty( "charset", "utf-8");
//                con.setRequestProperty("Content-Length", Integer.toString(jsonInputString.length()));
//
//
//                try(OutputStreamWriter osw = new OutputStreamWriter(con.getOutputStream())) {
//                    //  byte[] input = jsonInputString.getBytes("utf-8");
//        //            JSONObject obj=new JSONObject();
//        //            obj.put("feed_script",data);
//        //            os.write(obj, 0, obj.length);
//        //            DataOutputStream out = new DataOutputStream(os);
//        //            out.write(input);
//                    //OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
//                    //os.write(input, 0, input.length);
////                    PrintWriter writer = new PrintWriter(os);
////                    writer.print(jsonInputString);
//                    osw.write(jsonInputString);
//                    osw.flush();
//                    osw.close();
//                    con.getResponseCode();
//
//                    try(BufferedReader br = new BufferedReader(
//                            new InputStreamReader(con.getInputStream(), "utf-8"))) {
//                        StringBuilder response = new StringBuilder();
//                        String responseLine = null;
//                        while ((responseLine = br.readLine()) != null) {
//                            response.append(responseLine.trim());
//                        }
//                        adviceField.setText(response.toString());
//
//                        //System.out.println(response.toString());
//                    } catch (Exception e) {
//                        adviceField.append("\nbuffer reading failed\n");
//                        e.printStackTrace();
//                        //adviceField.setText("Please try again later!!!");
//                    }
//
//                } catch (Exception e) {
//                    adviceField.append("\noutput failed:"+e.toString()+"\n");
//                    e.printStackTrace();
//                    //adviceField.setText("Sorry try again later!!!");
//                }
//
////                try( DataOutputStream wr = new DataOutputStream( con.getOutputStream())) {
////                    byte[] input = jsonInputString.getBytes("utf-8");
////                    wr.write(input);
////                    wr.flush();
////                    wr.close();
////                } catch (Exception e) {
////                    e.printStackTrace();
////                    //adviceField.setText("Please try again later!!!");
////                }
//
//
//
//                con.disconnect();

///////////////////////////VOLLEY////////////////////////////
//
//                RequestQueue requestQueue;
//
//                // Instantiate the cache
//                Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB cap
//
//                // Set up the network to use HttpURLConnection as the HTTP client.
//                Network network = new BasicNetwork(new HurlStack());
//
//                // Instantiate the RequestQueue with the cache and network.
//                requestQueue = new RequestQueue(cache, network);
//
//                // Start the queue
//                requestQueue.start();
//
//                String url = "https://simplenodebackend.herokuapp.com/process_update";
//                //String url = "http://localhost:5000/process_update";
//                JSONObject jsonBody = new JSONObject();
//                try {
//                    jsonBody.put("feed_script",data);
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//                final String requestBody = jsonBody.toString();
//                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
//                    new Response.Listener<String>(){
//
//                        @Override
//                        public void onResponse(String response) {
//                            adviceField.append("\nresponse\n"+response.toString());
//                            //Toast.makeText(GetAdviceActivity.this,"response " + response.trim(), Toast.LENGTH_LONG).show();
//                        }
//                    },
//                    new Response.ErrorListener()
//                    {
//
//                        @Override
//                        public void onErrorResponse(VolleyError error) {
//                            error.printStackTrace();
//                            Toast.makeText(GetAdviceActivity.this,"error "+error.toString(), Toast.LENGTH_LONG).show();
//                        }
//                    }){
////                    @Override
////                    protected Map<String,String> getParams(){
////                        Map<String, String> params = new HashMap<String, String>();
////                        params.put("feed_script", data);
////
////                        //adviceField.append( "\ngetparams\n"+ params.toString());
////
////
////                        try {
////                            adviceField.append( "\ngetparams\n"+ params);
////                            return params;
////                        } catch (Exception e)
////                        {
////                            adviceField.append( "\ngetparams return null\n");
////                            e.printStackTrace();
////                            return null;
////                        }
////                    }
//
//                    @Override
//                    public byte[] getBody() throws AuthFailureError {
//
//                        //String requestBody = jsonInputString;  //The request body goes in here.
//                        try {
//                            adviceField.append( "\ngetbody\n"+ new String(requestBody.getBytes("utf-8"), StandardCharsets.UTF_8));
//                        } catch (UnsupportedEncodingException e) {
//                            adviceField.append( "\ngetbody getbyte problem\n");
//                            e.printStackTrace();
//                        }
//
//                        try {
//
//                            return requestBody.getBytes("utf-8");
//                        } catch (UnsupportedEncodingException e) {
//                            e.printStackTrace();
//                            VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", requestBody, "utf-8");
//                            adviceField.append( "\ngetbody return null\n");
//                            return null;
//                        }
//                    }
//
//
//                    @Override
//                    public Map<String, String> getHeaders() throws AuthFailureError {
//                        HashMap<String,String> headers = new HashMap<>();
//
//                        /*change content-type to "application/x-www-form-urlencoded" from
//                         "application/json"
//                         */
//
//                        headers.put("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
//                        return headers;
//                    }
//
//                    @Override
//                    public int getMethod() {
//                        return Method.POST;
//                    }
//
//                };
//
//                try {
//                    adviceField.append("\nreq body : " + new String(stringRequest.getBody(), StandardCharsets.UTF_8) + "\n");
//                } catch (AuthFailureError authFailureError) {
//                    authFailureError.printStackTrace();
//                    adviceField.append("\nreq body error : " + authFailureError.toString());
//                }
//
//
//                //RequestQueue requestQueue = Volley.newRequestQueue(GetAdviceActivity.this);
//                requestQueue.add(stringRequest);

                };





            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        //adviceField.setText(jsonInputString);

        //getadvice();


    }

    private void getadvice() {

        {
            try {
                //url = new URL ("https://simplenodebackend.herokuapp.com/process_update");
                url = new URL ("http://localhost:5000");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection)url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
            adviceField.setText("Sorry, couldn't connect to server!!!");
        }
        try {
            con.setRequestMethod("POST");
        } catch (ProtocolException e) {
            e.printStackTrace();
            adviceField.setText("Sorry, couldn't send request to server!!!");
        }

//        con.setRequestProperty("Content-Type", "application/json; utf-8");
//        con.setRequestProperty("Accept", "application/string");
        con.setDoOutput(true);
        con.setDoInput(true);
        con.setAllowUserInteraction(true);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        con.setRequestProperty( "charset", "utf-8");
        con.setRequestProperty("Content-Length", Integer.toString(jsonInputString.length()));




//        try(OutputStream os = con.getOutputStream()) {
//            //  byte[] input = jsonInputString.getBytes("utf-8");
////            JSONObject obj=new JSONObject();
////            obj.put("feed_script",data);
////            os.write(obj, 0, obj.length);
////            DataOutputStream out = new DataOutputStream(os);
////            out.write(input);
//            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
//            //os.write(input, 0, input.length);
//            osw.write(jsonInputString);
//            osw.flush();
//            osw.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//            //adviceField.setText("Sorry try again later!!!");
//        }

        try( DataOutputStream wr = new DataOutputStream( con.getOutputStream())) {
            byte[] input = jsonInputString.getBytes("utf-8");
            wr.write(input);
            wr.flush();
            wr.close();
        } catch (Exception e) {
            e.printStackTrace();
            //adviceField.setText("Please try again later!!!");
        }

        try(BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            adviceField.setText(response.toString());
            //System.out.println(response.toString());
        } catch (Exception e) {
            e.printStackTrace();
            //adviceField.setText("Please try again later!!!");
        }

        con.disconnect();

    }
}