package com.example.mycovidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CheckStatusActivity extends AppCompatActivity {

    private EditText quesField;
    private Button cpos;
    private Button cneg;
    private Button crec;
    private Button back;

    private FirebaseAuth mAuth;
    private DatabaseReference mDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_status);

        mAuth = FirebaseAuth.getInstance();

        mDataBase = FirebaseDatabase.getInstance().getReference().child("Users");

        quesField = findViewById(R.id.questionField);
        quesField.setEnabled(false);
        cpos = findViewById(R.id.cpos);
        cneg = findViewById(R.id.cneg);
        crec = findViewById(R.id.crec);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(CheckStatusActivity.this, MapsActivity.class);
                mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
            }
        });

        cpos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user_id = mAuth.getCurrentUser().getUid();
                DatabaseReference curr = mDataBase.child(user_id);

                curr.child("Status").setValue("I");//infected

            }
        });

        cneg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_id = mAuth.getCurrentUser().getUid();
                DatabaseReference curr = mDataBase.child(user_id);

                curr.child("Status").setValue("S");

            }
        });

        crec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_id = mAuth.getCurrentUser().getUid();
                DatabaseReference curr = mDataBase.child(user_id);

                curr.child("Status").setValue("R");//recovered

            }
        });
    }
}