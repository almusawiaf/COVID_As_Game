package com.example.mycovidapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private EditText mLoginEmailField;
    private EditText mPassword;
    private Button mLoginBtn;
    private Button mNewAccBtn;

    private FirebaseAuth mAuth;
    private DatabaseReference mDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        mDataBase = FirebaseDatabase.getInstance().getReference().child("Users");

        mLoginEmailField = (EditText) findViewById(R.id.loginEmailField);
        mPassword = (EditText) findViewById(R.id.editTextTextPassword);
        mLoginBtn = (Button) findViewById(R.id.loginBtn);
        mNewAccBtn = (Button) findViewById(R.id.newAccBtn);

        mNewAccBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent = new Intent(LoginActivity.this,RegisterActivity.class);
                regIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(regIntent);
            }
        });

        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLogin();
            }


        });

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        try {
            if(keyCode==KeyEvent.KEYCODE_BACK)
                Toast.makeText(LoginActivity.this, "Please Login",
                        Toast.LENGTH_SHORT).show();

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return false;
        // Disable back button..............
    }

    private void checkLogin() {

        String email =mLoginEmailField.getText().toString().trim();
        String password = mPassword.getText().toString().trim();

        if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password))
        {
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        // Sign in success, update UI with the signed-in user's information
                        //checkUserExists();
                        Intent mainIntent = new Intent(LoginActivity.this, MapsActivity.class);
                        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(mainIntent);

                    } else {
                        // If sign in fails, display a message to the user.
                        FirebaseAuthException e = (FirebaseAuthException )task.getException();
                        Toast.makeText(LoginActivity.this, "Authentication failed." + e.getMessage(),
                                Toast.LENGTH_SHORT).show();

                    }

                }
            });
        }

    }

//    private void checkUserExists() {
//
//        final String user_id = mAuth.getCurrentUser().getUid();
//
//        mDataBase.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                 if(snapshot.hasChild(user_id))
//                 {
//                     Intent mainIntent = new Intent(LoginActivity.this, MapsActivity.class);
//                     mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                     startActivity(mainIntent);
//                 }
//                 else
//                 {
//                     Toast.makeText(LoginActivity.this, "You need to setup a new account." ,
//                             Toast.LENGTH_SHORT).show();
//                 }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//    }
}